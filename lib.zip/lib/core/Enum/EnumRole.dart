// ignore: file_names
enum Enumrole {
  // ignore: constant_identifier_names
  CUSTOMER,
  HOTEL
}
