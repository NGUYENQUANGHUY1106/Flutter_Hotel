class UtilConst {
  static const String idUser = "idUser";
  static const String token = "token";
  static const String refreshToken = "refreshToken";
  static const String phone = "phone";
  static const String password = "password";
}
