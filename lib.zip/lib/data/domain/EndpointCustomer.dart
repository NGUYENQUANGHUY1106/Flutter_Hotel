class Endpointcustomer {
   static const String signUp = "/customer";
   static const String getCustomer = "/customer";
   static const String bookHotel = "/book_hotel";
   static const String getAllBookHotelByIdUser = "/book_hotel";
   static const String updateStatusBooked = "/book_hotel";
   static const String searchhotel = "/hotel/search";
   static const String addRate = "/rate";
   static const String getAllRate = "/rate";
   static const String getDoanhThu = "/hotel/totalMoney";
   static const String getBookingStatusCount = "/hotel/bookings/count";
  static const String getAvailableRoomByUserId = "/hotel/available-rooms";
 }