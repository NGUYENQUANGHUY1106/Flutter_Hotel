// ignore: file_names
class BaseUrl {
  static const String baseUrl = "http://192.168.1.202:8080/mvc_10";
  static const String login = "/auth/login";

  
}

