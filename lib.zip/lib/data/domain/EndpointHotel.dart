// ignore: file_names
class Endpointhotel {
  static const String signUp = "/hotel";
  static const String uploadImg = "/hotel/uploadFile";
  static const String getAllHotel = "/hotel";
}
