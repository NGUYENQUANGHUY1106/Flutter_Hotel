class AppRoutes {
  static const introduce = "/introduce";
  static const login = "/login";
  static const home = '/home';
  static const signUp = "/signUp";
  static const signUpHotel = "/signUpHotel";
  static const indexuserscreen = "/indexuserscreen";
  static const vnpagePage = "/vnpagePage";
  static const detailHotelScreen = "/detailHotelScreen";
  static const detailBooked = "/detailBooked";
  static const hotelIndex = "/hotelIndex";
  static const hotelDetailBooked = "/hotelDetailBooked";
  // static const detailPost = "/detailPost";
  // static const confirmSuggest = "/confirmSuggest";
  // static const banking = "/banking";
  // static const notification = "/notification";
  // static const updateProfile = "/updateProfile";
  // static const stateRequest = "/stateRequest";
  // static const detailSuggest = "/detailSuggest";
}
